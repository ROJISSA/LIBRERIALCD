#ifdef Libreria_LCD.h
uint8_t I/D
void Pantalla_LCD_init(int RS, int RW, int DB7, int DB6, int DB5, int DB4, int DB3, int DB2, int DB1, int DB0);
void Clear_Display();
void Return_Home(int RS, int RW, int DB7, int DB6, int DB5, int DB4, int DB3, int DB2, int DB1);
void Entry_Mode_Set(int RS, int RW, int DB7, int DB6, int DB5, int DB4, int DB3, int DB2);
void Display_ON_OFF_Control(int RS, int RW, int DB7, int DB6, int DB5, int DB4, int DB3, int DB2, int DB1, int DB0);
void Cursor_OR_Display_Shift(int RS, int RW, int DB7, int DB6, int DB5, int DB4, int DB3, int DB2);
void Function_set(int RS, int RW, int DB7, int DB6, int DB5, int DB4, int DB3, int DB2, int DB2);
void Set_CGRAM_Address(int RS, int RW, int DB7, int DB6, int DB5, int DB4, int DB3, int DB2, int DB1, int DB0);
void Set_DDRAM_Address(int RS, int RW, int DB7, int DB6, int DB5, int DB4, int DB3, int DB2, int DB1, int DB0);
void Read_Busy_Flag_And_Address_Counter(int RS, int RW, int DB7, int DB6, int DB5, int DB4, int DB3, int DB2, int DB1, int DB0);
void Write_Data_To_RAM(int RS, int RW, int DB7, int DB6, int DB5, int DB4, int DB3, int DB2, int DB1, int DB0);
void Read_Data_From_RAM(int RS, int RW, int DB7, int DB6, int DB5, int DB4, int DB3, int DB2, int DB1, int DB0);
#endif